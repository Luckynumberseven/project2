-- Adminer 4.2.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pnr` varchar(150) COLLATE utf8_bin NOT NULL,
  `course_code` varchar(150) COLLATE utf8_bin NOT NULL,
  `grade` varchar(10) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `grades` (`id`, `pnr`, `course_code`, `grade`) VALUES
(1,	'666',	'FED1501',	'VG'),
(2,	'666',	'FED1502',	'G'),
(3,	'777',	'FED1501',	'G'),
(4,	'888',	'FED1406',	'VG'),
(6,	'666',	'FED1501',	'MVG'),
(7,	'777',	'FED1502',	'MVG'),
(8,	'777',	'FED1502',	'MVG'),
(9,	'111',	'FED1501',	'U'),
(10,	'888',	'FED1502',	'ZZZ');

-- 2016-03-09 09:23:25
