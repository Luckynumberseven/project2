<?php 
class DB{

	private static $instance;	

	public static function getInstance(){
		if(!self::$instance){ // If no instance create new connection to database
			require_once('db.conf.php');
			self::$instance = new mysqli(CONF_DB_SERVER,CONF_DB_USERNAME,CONF_DB_PASSWORD,CONF_DB_DATABASE);
			self::$instance->query("SET NAMES 'utf8'");
			return self::$instance;
		}else{ // If we already have an instance
			return self::$instance;
		}
	}

	private function __construct(){}
	private function __clone(){}
}