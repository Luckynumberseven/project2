<?php

class grades {

	// Returns list of all grades when visiting /?grades
	public function get($data = NULL) {
		$db = DB::getInstance();
	
		$query = 
				"SELECT pnr, course_code, grade FROM grades";
		$result = $db->query($query);
		while( $row = $result->fetch_assoc() ) {
			echo $row['course_code'].'<br>'.$row['pnr'].'<br>'.$row['grade'].'<br>';
		}
	
	}
}