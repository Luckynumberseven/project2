<?php
error_reporting(0);

$url_parts = getUrlParts($_GET);

$method = $_SERVER['REQUEST_METHOD']; /* Sets request method */
$resource = $url_parts[0]; /* Sets class to call */

$allowed_resources = ['course', 'student', 'grades']; /* Callable classes */

if(in_array($resource, $allowed_resources)){
	require_once($resource.".class.php");
	$obj = new $resource($url_parts[1]); /* Creates new object of requested class with the course-code as parameter for the constructor */
	$obj->$method($url_parts[2]); /* Calls appropriate method in class depending on request method. passes parameter for grade requests */
}
else{
	header("HTTP/1.1 404 Not Found");
}

function getUrlParts($get){
	$get_params = array_keys($get);
	$url = $get_params[0];
	$url_parts = explode("/",$url);
	foreach($url_parts as $k => $v){
		if($v) $array[] = $v;
	}

	$url_parts = $array;
	return $url_parts; 
}

function __autoload($class){
	require_once($class.".class.php");
}
