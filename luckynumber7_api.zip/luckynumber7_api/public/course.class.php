<?php

class course{

	public $id;

	function __construct($id = NULL) {
		$this->id = $id;
	}

	public function get( $data = NULL ){
		$db = DB::getInstance();

		/* When grade is requested. URL ending with /grades */
		if( $data == 'grades' ) {

			/* Shows specific student grades if student-id is passed from GET. /?course/[course code]/grades/&student=[pnr] */
			if( isset($_GET['student'])) {
				$student = filter_var($_GET['student']);
				$query = 
					"SELECT course_code, pnr, grade FROM grades WHERE course_code = '$this->id' AND pnr = '$student'";
			}
			/* Shows all students grades in a given course. /?course/[course code]/grades*/
			elseif( !isset($_GET['student']) && $this->id != NULL ) {
				$query = 
					"SELECT DISTINCT course_code, pnr, grade FROM grades WHERE course_code = '$this->id'";
			}
			/* If no course or student been delivered (Practically impossible because grades are dependable upon course-code)*/
			else {
				$query = "SELECT course_code, pnr, grade FROM grades";
			}

			$result = $db->query($query);

			while( $row = $result->fetch_assoc() ) {
				echo $row['course_code'].'<br>'.$row['pnr'].'<br>'.$row['grade'].'<br>';
			}
		}

		/* If grades are not requested. URL not ending with /grades */
		if($data == NULL) { 
			
			/* When calling a specific course code. /?course/[course code] */
			if( $this->id != NULL ) {
				$query = "SELECT DISTINCT course_code FROM grades WHERE course_code = '$this->id'";
			}
			/* When not calling a specific course code. /?course */
			else {
				$query = "SELECT DISTINCT course_code FROM grades";				
			}

			$result = $db->query($query);

			while( $row = $result->fetch_assoc() ) {
				echo $row['course_code'].'<br>';
				
			}	
		}
	}

	public function post( $data = NULL ){
		$db = DB::getInstance();

		/* Recieves and adds new grade for a specified student */
		if( $data == 'grades' && isset( $_POST['student'] ) && isset( $_POST['grade'] ) ) {
			
			$pnr = $db->real_escape_string($_POST['student']);
			$grade = $db->real_escape_string($_POST['grade']);

			$query =
					"INSERT INTO grades(pnr, course_code, grade)
					VALUES ('$pnr', '$this->id', '$grade')";
			
			$result = $db->query($query);

			echo 'Betyget '.$grade.' tillagt för student med personnummer '.$pnr.' i kursen med kod '.$this->id.'.';
		}	
	}

	public function put( $data = NULL ){
		$db = DB::getInstance();

		$pnr = $db->real_escape_string($_GET['student']);
		$grade = $db->real_escape_string($_GET['new_grade']);

		$query =
				"UPDATE grades
				SET grade = '$grade'
				WHERE course_code = '$this->id'
				AND pnr = $pnr";
		$db->query($query);

		echo 'Betyget uppdaterat till '.$grade.' för student med personnummer '.$pnr.' i kursen med kod '.$this->id.'.';
	}

}