<?php

class student{

	public $id;

	function __construct($id = NULL) {
		$this->id = $id;
	}

	public function get($data = NULL){
		
		$db = DB::getInstance();

		// Displays students
		if( $data == NULL) {

			// Specified student. ?/student/[pnr]
			if( $this->id != NULL ) {
				$query = 
					"SELECT DISTINCT pnr FROM grades WHERE pnr = '$this->id'";
			}

			// All students. ?/student
			else {
				$query = 
					"SELECT DISTINCT pnr FROM grades";
			}
				
			$result = $db->query($query);

			while( $row = $result->fetch_assoc() ) {
				echo $row['pnr'].'<br>';
			}
		}
		
	}
}