<?php
define('CONF_DB_SERVER', 'localhost');
define('CONF_DB_USERNAME', 'root');
define('CONF_DB_PASSWORD', 'root');
define('CONF_DB_DATABASE', 'lucky_api');