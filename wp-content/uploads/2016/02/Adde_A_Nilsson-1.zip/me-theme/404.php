<?php
get_header();
?>
<div class="row">
	<div class="col-xs-12 page-content">
	<div class="row">
		<div class="col-xs-9 page-head">
			<h1 class="text-center">No page here!</h1>
			<p>This url does not host a page! Maybe you've misspelled, or maybe I made something wrong. Anyhow you can use the links above
			 or the sidebar to navigate yourself to some real content</p>
		</div>
		<div class="col-xs-3 sidebar-area">
			<?php get_sidebar() ?>
		</div>
	</div>
	</div>
</div>
<div class="content-404">
	
</div>

<?php
get_footer()
?>