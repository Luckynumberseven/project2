<?php get_header() ?>

<?php
if( have_posts()) : 
	while( have_posts() ) : the_post();
?>
		<div class="row ">
			<div class="col-xs-12 page-head">
					<h1 class=""><?php the_archive_title(); ?></h1>
				<p>This is the archive page for <?php the_archive_title() ?>.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 page-content">

				<div class="row">
					<div class="col-xs-9">
						<a href="<?php the_permalink() ?>">
							<h1><?php the_title(); ?> </h1>
							<?php the_excerpt();?>
						</a>

						
					</div>
					<div class="col-xs-3">
						<?php get_sidebar(); ?>
					</div>
				</div>		
			</div>
		</div>	
	<?php
	endwhile;		
else : 
	?>
	<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php 
endif; 
?>

<?php get_footer() ?>