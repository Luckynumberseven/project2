<?php
get_header()
?>
<?php 

if ( is_404() ) : get_template_part('404.php');
endif
?>

<div class="row ">
	<div class="col-xs-12 page-head welcome">
		<?php
		if( have_posts()) : 
			while( have_posts() ) : the_post();
		?>
				<h1 class="text-center"><?php the_title(); ?></h1>
					<?php the_content() ?>
			<?php
			endwhile;		
		else : ?>
			<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
		<?php 
		endif; ?>
	</div>
</div>
<div class="row">
	<div class="col-xs-12 page-content">
		<div class="row">
			<div class="col-xs-9 ">
				<div class="row">
					<div class="col-xs-12 front-page-area">
						<div class="row">
							<h1 class="text-center blue-back">Portfolios</h1>
							<?php
							// Loops our Portfolio custom post types
							$portfolio = new WP_query(['post_type' => 'portfolio']);

							if( $portfolio->have_posts() ) : 
								while( $portfolio->have_posts() ) : $portfolio->the_post() ;
							?>
									<div class="col-xs-6 portfolio">
										<img class="img-responsive center-block" src="<?php the_field('screenshot') ?>" />
										<a href="<?php the_permalink(); ?>">
											<h3 class="text-center"><?php the_title(); ?></h3>
											<p><?php the_content() ?></p>
										</a>
									</div>
								<?php 
								endwhile; 
							else : ?>
								<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
							<?php 
							endif;	
							?>
						</div>
					</div>

					<div class="col-xs-12 front-page-area">
						<div class="row">
							<h1 class="text-center blue-back">Bands</h1>
							
							<?php
							// Loops our Band custom post types
							$band = new WP_query(['post_type' => 'band']);

							if( $band->have_posts() ) :
								while( $band -> have_posts() ) : $band->the_post();
							?>
								<div class="col-xs-12 band">
									<div class="row">
										<div class="col-xs-5">
											<img class="img-responsive center-block logo" src="<?php the_field('logo') ?>" />
										</div>
										<div class="col-xs-7">
											<a href="<?php the_permalink(); ?>">
												<h3 class=""><?php the_title(); ?></h3>
												<p><?php the_content() ?></p>
											</a>
										</div>
									</div>
								</div>
								<?php
								endwhile;
							else : ?>
								<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
							<?php 
							endif;
							?>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xs-3 sidebar-area">
				<?php
				get_sidebar();
				?>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-xs-12">
		<?php
		get_footer();
		?>
	</div>
</div>

