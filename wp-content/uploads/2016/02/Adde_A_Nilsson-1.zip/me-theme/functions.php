<?php

// Loads our stylesheet
function load_scripts() {
	wp_enqueue_style('adde-style', get_stylesheet_uri());
}

add_action('wp_enqueue_scripts', 'load_scripts');

//Sets the length of all the_excerpt calls to 15 words instead of the default 55 words
function custom_excerpt_length( $length ) {
    return 15;
}
add_filter( 'excerpt_length', 'custom_excerpt_length' );

################################# Widget areas ######################################################

//Creates three widget-area sidebars
function sidebars(){

	register_sidebar([
		'name' => 'My Sidebar',
		'id' => 'sidebar-1',
        'before_title' => '<h3>',
        'after_title' => '</h3>'
		]);
	register_sidebar([
		'name' => 'My Footerbar',
		'id' => 'sidebar-2',
        'description' => 'For best layout add 4 widgets. No more, no less.',
        'before_widget' => '<div class="col-xs-3">',
        'after_widget' => '</div>',
        'before_title' => '<h5 class="widget-title">',
        'after_title' => '</h5>'
		]);
    register_sidebar([
        'name' => 'Next Level Footerbar',
        'id' => 'sidebar-3',
        'description' => 'Add a second level of widgets to your footer. For best layout add 4 widgets. No more, no less.',
        'before_widget' => '<div class="col-xs-3">',
        'after_widget' => '</div>',
        'before_title' => '<h5 class="widget-title">',
        'after_title' => '</h5>'
        ]);
}
//Loads our sidebars
add_action('widgets_init', 'sidebars'); //Parametrar: När i körningen ska vår kod köras och vilken av våra funtioner ska då köras

// Creates primary and secondary customizeble top menu
function menus() {
    register_nav_menus([
        'primary' => 'Top Left menu',
        'secondary' => 'Top Right menu']);
}
add_action('after_setup_theme','menus');


################################# Post-types ######################################################


function post_type_portfolio_init() {
	//For dashboard view
    $labels = array(
            'name'                  => "Portfolio",
            'singular_name'         => "Portfolio",
            'menu_name'             => "Portfolio",
            'name_admin_bar'        => "Portfolio",
            'add_new'               => __( 'Add New', 'textdomain' ),
            'add_new_item'          => __( 'Add New Portfolio', 'textdomain' ),
            'new_item'              => __( 'New Portfolio', 'textdomain' ),
            'edit_item'             => __( 'Edit Portfolio', 'textdomain' ),
            'view_item'             => __( 'View Portfolio', 'textdomain' ),
            'all_items'             => __( 'All Portfolios', 'textdomain' ),
            'search_items'          => __( 'Search Portfolios', 'textdomain' ),
            'parent_item_colon'     => __( 'Parent Portfolios:', 'textdomain' ),
            'not_found'             => __( 'No Portfolios found.', 'textdomain' ),
            'not_found_in_trash'    => __( 'No Portfolios found in Trash.', 'textdomain' ),
            'featured_image'        => _x( 'Portfolio Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'archives'              => _x( 'Portfolio archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
            'insert_into_item'      => 'Insert into Portfolio',//_x( 'Insert into Portfolio', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this Portfolio', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
            'filter_items_list'     => _x( 'Filter Portfolios list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
            'items_list_navigation' => _x( 'Portfolios list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
            'items_list'            => _x( 'Portfolios list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
        );
 	//Arguments for our new post type
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'portfolio' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'register_meta_box_cb' => 'add_portfolio_metabox'

    );

    // Registers our custom post type with above arguments
	register_post_type('portfolio', $args);
}

    add_action('init', 'post_type_portfolio_init');

function post_type_band_init() {
    //For dashboard view
    $labels = array(
            'name'                  => "Band",
            'singular_name'         => "Band",
            'menu_name'             => "Band",
            'name_admin_bar'        => "Band",
            'add_new'               => __( 'Add New', 'textdomain' ),
            'add_new_item'          => __( 'Add New Band', 'textdomain' ),
            'new_item'              => __( 'New Band', 'textdomain' ),
            'edit_item'             => __( 'Edit Band', 'textdomain' ),
            'view_item'             => __( 'View Band', 'textdomain' ),
            'all_items'             => __( 'All Bands', 'textdomain' ),
            'search_items'          => __( 'Search Bands', 'textdomain' ),
            'parent_item_colon'     => __( 'Parent Bands:', 'textdomain' ),
            'not_found'             => __( 'No Bands found.', 'textdomain' ),
            'not_found_in_trash'    => __( 'No Bands found in Trash.', 'textdomain' ),
            'featured_image'        => _x( 'Band Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'archives'              => _x( 'Band archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
            'insert_into_item'      => 'Insert into Band',//_x( 'Insert into Band', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this Band', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
            'filter_items_list'     => _x( 'Filter Bands list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
            'items_list_navigation' => _x( 'Bands list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
            'items_list'            => _x( 'Bands list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
        );
    //Arguments for our new post type
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'band' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'register_meta_box_cb' => 'add_band_metabox'
    );

    //Registers our custom post type with above argument
    register_post_type('band', $args);
}

    add_action('init', 'post_type_band_init');

function post_type_album_init() {
    //For dashboard view
    $labels = array(
            'name'                  => "Album",
            'singular_name'         => "Album",
            'menu_name'             => "Album",
            'name_admin_bar'        => "Album",
            'add_new'               => __( 'Add New', 'textdomain' ),
            'add_new_item'          => __( 'Add New Album', 'textdomain' ),
            'new_item'              => __( 'New Album', 'textdomain' ),
            'edit_item'             => __( 'Edit Album', 'textdomain' ),
            'view_item'             => __( 'View Album', 'textdomain' ),
            'all_items'             => __( 'All Albums', 'textdomain' ),
            'search_items'          => __( 'Search Albums', 'textdomain' ),
            'parent_item_colon'     => __( 'Parent Albums:', 'textdomain' ),
            'not_found'             => __( 'No Albums found.', 'textdomain' ),
            'not_found_in_trash'    => __( 'No Albums found in Trash.', 'textdomain' ),
            'featured_image'        => _x( 'Album Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'archives'              => _x( 'Album archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
            'insert_into_item'      => 'Insert into Album',//_x( 'Insert into Album', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this Album', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
            'filter_items_list'     => _x( 'Filter Albums list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
            'items_list_navigation' => _x( 'Albums list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
            'items_list'            => _x( 'Albums list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
        );
    //Arguments for our new post type
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'album' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'register_meta_box_cb' => 'add_album_metabox'
    );

    //Registers our custom post type with above argument
    register_post_type('album', $args);
}

    add_action('init', 'post_type_album_init');

function post_type_school_init() {
    //For dashboard view
    $labels = array(
            'name'                  => "School",
            'singular_name'         => "School",
            'menu_name'             => "School",
            'name_admin_bar'        => "School",
            'add_new'               => __( 'Add New', 'textdomain' ),
            'add_new_item'          => __( 'Add New School', 'textdomain' ),
            'new_item'              => __( 'New School', 'textdomain' ),
            'edit_item'             => __( 'Edit School', 'textdomain' ),
            'view_item'             => __( 'View School', 'textdomain' ),
            'all_items'             => __( 'All Schools', 'textdomain' ),
            'search_items'          => __( 'Search Schools', 'textdomain' ),
            'parent_item_colon'     => __( 'Parent Schools:', 'textdomain' ),
            'not_found'             => __( 'No Schools found.', 'textdomain' ),
            'not_found_in_trash'    => __( 'No Schools found in Trash.', 'textdomain' ),
            'featured_image'        => _x( 'School Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
            'archives'              => _x( 'School archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
            'insert_into_item'      => 'Insert into School',//_x( 'Insert into School', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this School', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
            'filter_items_list'     => _x( 'Filter Schools list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
            'items_list_navigation' => _x( 'Schools list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
            'items_list'            => _x( 'Schools list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
        );
    //Arguments for our new post type
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'school' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'register_meta_box_cb' => 'add_school_metabox'
    );

    //Registers our custom post type with above argument
    register_post_type('school', $args);
}
   
    add_action('init', 'post_type_school_init');


#################################### Meta-boxes / Custom Fields #########################################


/* Meta for Portfolio post type */

// Adds the meta-box, called from register_post_type
function add_portfolio_metabox() {
    add_meta_box('portfolio_meta', 'Portfolio Details', 'portfolio_meta_fields', 'portfolio', 'normal', 'high');
}

// Adds content to our meta-box from template, called from add_meta_box
function portfolio_meta_fields() {
    get_template_part('template-parts/custom-fields-portfolio');
}

//Handles saving values for our meta-data. Our POST values for each field is added to the array. Loop checks wether to update or insert new values
function save_portfolio_meta($post_id, $post) {
    $portfolio_meta['name'] = $_POST['name'];
    $portfolio_meta['project_url'] = $_POST['project_url'];
    $portfolio_meta['project_year'] = $_POST['project_year'];
    $portfolio_meta['people'] = $_POST['people'];

    foreach($portfolio_meta as $key => $value){
        if(get_post_meta($post->ID, $key, FALSE)){
            update_post_meta($post->ID, $key, $value); 
        }
        else {
            add_post_meta($post->ID, $key, $value);
        }
    }
}
add_action('save_post', 'save_portfolio_meta',1,2);

/* Meta for Band post type */

function add_band_metabox() {
    add_meta_box('band_meta', 'Band Details', 'band_meta_fields', 'band', 'normal', 'high');
}

function band_meta_fields() {
    get_template_part('template-parts/custom-fields-band');
}

function save_band_meta($post_id, $post) {
    $band_meta['name'] = $_POST['name'];
    $band_meta['band_url'] = $_POST['band_url'];
    $band_meta['band_email'] = $_POST['band_email'];
    $band_meta['is_active'] = $_POST['is_active'];
    $band_meta['disband_year'] = $_POST['disband_year'];
    $band_meta['song_url'] = $_POST['song_url'];

    foreach($band_meta as $key => $value){
        if(get_post_meta($post->ID, $key, FALSE)){
            update_post_meta($post->ID, $key, $value); 
        }
        else {
            add_post_meta($post->ID, $key, $value);
        }
    }
}
add_action('save_post', 'save_band_meta',1,2);

/* Meta for album post type */

function add_album_metabox() {
    add_meta_box('album_meta', 'Album Details', 'album_meta_fields', 'album', 'normal', 'high');
}

function album_meta_fields() {
    get_template_part('template-parts/custom-fields-album');
}

function save_album_meta($post_id, $post) {
    $album_meta['band_name'] = $_POST['band_name'];
    $album_meta['album_title'] = $_POST['album_title'];
    $album_meta['rel_year'] = $_POST['rel_year'];
    $album_meta['rec_label'] = $_POST['rec_label'];
    $album_meta['url_album'] = $_POST['url_album'];

    foreach($album_meta as $key => $value){
        if(get_post_meta($post->ID, $key, FALSE)){
            update_post_meta($post->ID, $key, $value); 
        }
        else {
            add_post_meta($post->ID, $key, $value);
        }
    }
}
add_action('save_post', 'save_album_meta',1,2);

/* Meta for school post type */

function add_school_metabox() {
    add_meta_box('school_meta','Education Details', 'school_meta_fields', 'school', 'normal', 'high');
}


function school_meta_fields() {
    get_template_part('template-parts/custom-fields-school');
}

function save_school_meta($post_id, $post){
    $school_meta['name_of_education'] = $_POST['name_of_education'];
    $school_meta['school_name'] = $_POST['school_name'];
    $school_meta['education_type'] = $_POST['education_type'];
    $school_meta['start'] = $_POST['start'];
    $school_meta['end'] = $_POST['end'];
    $school_meta['grad'] = $_POST['grad'];

    foreach($school_meta as $key => $value) {
        if(get_post_meta($post->ID, $key, FALSE)){
            update_post_meta($post->ID, $key, $value); 
        }
        else {
            add_post_meta($post->ID, $key, $value);
        }
    }

}
add_action('save_post', 'save_school_meta',1,2);


######################################### Customize ############################################################


//Creates customize-options for theme
function my_customize_register( $wp_customize ) {

//Creates options for colors on page:
    $wp_customize->add_setting( 'background', ['default' => '#0d1114', 'transport' => 'refresh']);
    $wp_customize->add_section('adde_colors', ['title' => 'Theme colors', 'priority' => 0]);
    $wp_customize->add_control(
        new WP_Customize_Color_Control($wp_customize, 'background', [
            'label' => 'Page Background-color',
            'section' => 'adde_colors',
            'setting' => 'background'])
        );

    $wp_customize->add_setting( 'paragraph', ['default' => '#D33F49', 'transport' => 'refresh']);
    $wp_customize->add_control(
        new WP_Customize_Color_Control($wp_customize, 'paragraph', [
            'label' => 'Text-color',
            'section' => 'adde_colors',
            'setting' => 'paragraph'])
        );
    $wp_customize->add_setting( 'link_color', ['default' => '#D33F49', 'transport' => 'refresh']);
    $wp_customize->add_control(
        new WP_Customize_Color_Control($wp_customize, 'link_color', [
            'label' => 'Link-color',
            'section' => 'adde_colors',
            'setting' => 'link_color',
            ])
        );
    $wp_customize->add_setting( 'frame_color', ['default' => '#17183B', 'transport' => 'refresh']);
    $wp_customize->add_control(
        new WP_Customize_Color_Control($wp_customize, 'frame_color', [
            'label' => 'Front page frame color',
            'section' => 'adde_colors',
            'setting' => 'frame_color',
            ])
        );
    $wp_customize->add_setting( 'content-bg', ['default' => '#191816', 'transport' => 'refresh']);
    $wp_customize->add_control(
        new WP_Customize_Color_Control($wp_customize, 'content-bg', [
            'label' => 'Content Background-color',
            'section' => 'adde_colors',
            'setting' => 'content-bg',
            ])
        );

//Creates options for header content
    $wp_customize->add_section( 'header_content', ['title' => 'Header Text', 'priority' => 0]);
    $wp_customize->add_setting( 'header_title', ['default' => 'Welcome!', 'transport' => 'refresh']);
    $wp_customize->add_control(
        new WP_customize_control($wp_customize, 'header_title', [
            'label' => 'Header welcome title',
            'section' => 'header_content',
            'setting' => 'header_title',
            'description' => 'Add a title for the header text.'
            ]));
    $wp_customize->add_setting('header_text', ['default' => 'Welcome to my site!', 'transport' => 'refresh']);
    $wp_customize->add_control(
        new WP_customize_control($wp_customize, 'header_text', [
            'label' => 'Header welcome text',
            'section' => 'header_content',
            'setting' => 'header_text',
            'description' => 'Add some text to the header.'
            ]));
    $wp_customize->add_setting( 'hide_content', ['default' => 0]);
    $wp_customize->add_control( 
        new WP_customize_control($wp_customize, 'hide_content', [
        'label' => 'Hide header text section',
        'type' => 'checkbox',
        'section' => 'header_content'
        ]));
    $wp_customize->add_setting( 'hide_logo', ['default' => 0]);
    $wp_customize->add_control(
        new WP_customize_control($wp_customize, 'hide_logo', [
        'label' => 'Hide header site logo',
        'type' => 'checkbox',
        'section' => 'header_content'
        ]));

//Creats option for changing background image
    $wp_customize->add_setting('background-image', ['default' => 'wp-content/themes/me-theme/image/blackback.png', 'transport' => 'refresh']);
    $wp_customize->add_control(
        new WP_Customize_Image_Control($wp_customize, 'background-image', [
            'label' => 'Background image',
            'section' => 'adde_colors',
            'setting' => 'background-image']
        ));
    
}

add_action('customize_register','my_customize_register'); 

//Calls the customized styles into the head of the page using the wp_head function
function theme_customize_css(){

    ?>
         <style type="text/css">
             body { background-color:<?php echo get_theme_mod('background'); ?>; }
             body {background-image: url('<?php echo get_theme_mod("background-image") ?>');}
             body { color:<?php echo get_theme_mod('paragraph'); ?>; }
             a { color: <?php echo get_theme_mod('link_color') ?>;}
             .site-header, .sidebar-area, .page-head, .page-content { background: <?php echo get_theme_mod('content-bg') ?>;}
             .blue-back {background-color: <?php echo get_theme_mod('frame_color') ?>;}
             .front-page-area { border-color: <?php echo get_theme_mod('frame_color') ?> ;}
         </style>
    <?php
}
add_action( 'wp_head', 'theme_customize_css');


############################################# Taxonomies ################################################


//Creates the 'Genre' taxonomy for our custom post type Band. Short style
function create_band_taxonomy() {
  register_taxonomy(
    'genre',
    array('band', 'album'),
    array(
      'label' => 'Genre',
      'rewrite' => array( 'slug' => 'genre' ),
      'hierarchical' => false,
    )
  );
}
add_action( 'init', 'create_band_taxonomy' );

//Creates the 'Tech' taxonomy for our custom post type Portfolio. Longer style
function create_portfolio_taxonomy() {
        $labels = array(
        'name'              => 'Techs',
        'singular_name'     => 'Tech',
        'search_items'      => 'Search Techs',
        'all_items'         => 'All Techs',
        'parent_item'       => 'Parent Tech',
        'parent_item_colon' => 'Parent Tech:',
        'edit_item'         => 'Edit Tech',
        'update_item'       => 'Update Tech',
        'add_new_item'      => 'Add New Tech',
        'new_item_name'     => 'New Tech Name',
        'menu_name'         => 'Tech',
    );
 
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'tech' ),
    );
 
    register_taxonomy( 'tech', 'portfolio', $args );
}
add_action( 'init', 'create_portfolio_taxonomy' );

//Creates the 'Education Level' taxonomy for our custom post type School.
function create_education_level_taxonomy() {
        $labels = array(
        'name'              => 'Education levels',
        'singular_name'     => 'Education level',
        'search_items'      => 'Search Education levels',
        'all_items'         => 'All Education levels',
        'parent_item'       => 'Parent Education level',
        'parent_item_colon' => 'Parent Education level:',
        'edit_item'         => 'Edit Education level',
        'update_item'       => 'Update Education level',
        'add_new_item'      => 'Add New Education level',
        'new_item_name'     => 'New Education level Name',
        'menu_name'         => 'Education level',
    );
 
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'education_level' ),
    );
 
    register_taxonomy( 'education_level', 'school', $args );
}
add_action( 'init', 'create_education_level_taxonomy' );

?>