<?php
get_header();
?>
<div class="row">
	<div class="col-xs-12 page-head text-center">
		<h1 class=""><?php the_archive_title();?> search</h1>
		<p>This is the search results page. Here you'll find links to all posts matching your search keyword.</p>
	</div>
</div>

<div class="row"><!--main-row-->
	<div class="col-xs-12  page-content"><!--main-col-->
		<div class="row">
			<div class="col-xs-9 archive-band">
				<?php
				//Sorterar om så äldsta inlägg hamnar först
				query_posts($query_string."&orderby=date&order=ASC");
				if( have_posts() ) :
					while( have_posts() ) : the_post();
					?>
						<div class="row">
						<div class="col-xs-2">
								<h4><?php echo ucfirst(get_post_type()) ?></h4>
							</div>
							<div class="col-xs-4">
								<img class="img-responsive" src=" <?php the_field('logo'); ?>"/>
								<img class="img-responsive" src=" <?php the_field('cover'); ?>"/>
							</div>
							
							<div class="col-xs-4">
								<a href="<?php the_permalink() ?>">
									<h1><?php the_title();?></h1> 
									<p><?php the_excerpt()?></p>
								</a>
							</div>
						</div>
					<?php
					endwhile;
					
				else : ?>
					<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
				<?php 
				endif;
				?>
			</div>

			<div class="col-xs-3">
				<?php
					get_sidebar();
				?>
			</div>
		</div>
	</div><!--/main-col-->
</div><!--/main-row-->

<div class="row">
	<div class="col-xs-12">
		<?php
		get_footer();
		?>
	</div>
</div>