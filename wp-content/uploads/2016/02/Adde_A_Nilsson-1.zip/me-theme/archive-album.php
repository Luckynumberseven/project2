<?php
get_header();
?>
<div class="row">

	<div class="col-xs-12 page-head text-center">
		<h1 class=""><?php the_archive_title();?></h1>
		<p>This is the archive page for albums. Here you'll find links to all albums posted on the site.</p>
		<h3>Browse albums and bands by genre:</h3>
		<?php
		/* Plockar alla terms i vår Taxonomy som är knuten till denna custom post type */
			$separator = ', ';
			$terms = wp_list_categories( 'title_li=&style=none&echo=0&taxonomy=genre&include=' );
			$terms = rtrim( trim( str_replace( '<br />',  $separator, $terms ) ), $separator );
			
			// display post taxonomy terms
			echo  $terms;
		?>
	</div>
</div>

<div class="row"><!--main-row-->
	<div class="col-xs-12  page-content"><!--main-col-->
		<div class="row">
			<div class="col-xs-9 archive-album">
				<?php
			//Sorterar om så äldsta inlägg hamnar först
				query_posts($query_string."&orderby=date&order=ASC");
				if( have_posts() ) :
					while ( have_posts() ) : the_post();

					get_template_part('template-parts/partial-album');

				endwhile;
				else : ?>
						<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
					<?php 
					endif;
				?>
			</div>

			<div class="col-xs-3">
				<?php
					get_sidebar();
				?>
			</div>
		</div>
	</div><!--/main-col-->
</div><!--/main-row-->

<div class="row">
	<div class="col-xs-12">
		<?php
		get_footer();
		?>
	</div>
</div>