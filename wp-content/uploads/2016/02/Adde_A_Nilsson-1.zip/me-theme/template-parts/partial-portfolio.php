<?php 
if (is_singular()) :
?>
	<div class="row">
		<div class="col-xs-12 page-content partial-portfolio">
			<div class="row">
				<div class="col-xs-10 col-xs-offset-1">
					<img class="img-responsive center-block" src="<?php the_field('screenshot')?>" />
				</div>
			</div>
			<div class="row">
				<div class="col-xs-10 col-xs-offset-1">
					<h1><?php the_title() ?></h1>
						<?php the_content() ?>
					<?php
					if( !empty(	get_post_meta($post->ID, 'project_url', true) )) : ?>
						<div class="p-content">
							<h3>Project link:
							<a href="<?php echo get_post_meta($post->ID, 'project_url', true)?>"><?php echo get_post_meta($post->ID, 'name', true)?></a></h3>
						</div>
					<?php
					endif
					?>
					<?php
					if( !empty( get_post_meta($post->ID, 'project_year', true) )) : ?>
						<p>This project was conducted in <?php echo get_post_meta($post->ID, 'project_year', true)?>.</p>
					<?php
					endif
					?>
					<?php
					if( !empty( get_post_meta($post->ID, 'people', true) )) : 
					?>						
						<p>Made together with the amazing 
						<?php echo get_post_meta($post->ID, 'people', true)?></p>
					<?php
					endif
					?>
					<?php
						if(!empty(get_the_terms($post->id, 'tech'))) :
						the_terms($post->id, 'tech', '<h3>Techs: </h3>', ', ', '.');
					endif
					?>
				</div>
			</div>
		</div>
	</div>
<?php
elseif(is_archive()) :
?>
	<div class="row">
		<div class="col-xs-6">
			<h1><a href=" <?php the_permalink() ?>"><?php the_title() ?></a></h1>
			<?php the_excerpt();?>
		</div>
		<div class="col-xs-6">
			<img class="img-responsive center-block" src="<?php the_field('screenshot')?>" />
		</div>
	</div>
<?php
endif
?>