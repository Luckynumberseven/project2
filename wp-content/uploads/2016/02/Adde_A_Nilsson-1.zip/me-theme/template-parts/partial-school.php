<?php 
	if (is_singular()) :
	/*Function ucfirst() for printing values of custom text fields and the title, turns the first letter uppercase, 
		to guarantee a structured print-out not depending on how the author originally posted it in the field */
?>	
	<div class="row">
		<div  class="col-xs-12 page-content">
			<div class="row">
				<div id="school" class="col-xs-10 col-xs-offset-1">
					<h1><?php echo ucfirst(get_the_title()) ?></h1>
					<h3>About this education</h3>
					<p><?php the_content() ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-xs-offset-1">
					<h4>Name of the school: </h4><h5><?php echo ucfirst(get_post_meta($post->ID, 'school_name', true)) ?>.</h5>
					<h4>Name of the education:</h4><h5> <?php echo ucfirst(get_post_meta($post->ID, 'name_of_education', true)) ?>.</h5>
					<h4>Type of education:</h4><h5> <?php echo ucfirst(get_post_meta($post->ID, 'education_type', true)) ?>.</h5>
				</div>
				<div class="col-xs-4">
					<h4>Education started:</h4><h5> <?php echo get_post_meta($post->ID, 'start', true) ?>.</h5>
					<h4>Education end:</h4><h5> <?php echo get_post_meta($post->ID, 'end', true) ?>.</h5>
					<h4>Graduated:</h4><h5><?php echo get_post_meta($post->ID, 'grad', true) ?>.</h5>
				</div>
				<div class="col-xs-3">
				<?php 
					if(!empty(get_the_terms($post->id, 'education_level', '', ', ', '.'))) :
						the_terms($post->id, 'education_level', '<h3>Education level</h3>', ', ', '');
					endif
					?>
				</div>
			</div>
		</div>
	</div>
<?php
	elseif (is_archive()) :
	?>
	<div id="school" class="col-xs-5 col-xs-offset-1">
		<a href="<?php the_permalink() ?>">
		<div class="school-entry">
			<h1><?php the_title()?></h1>
			<?php the_excerpt(); ?>
		</div>
	</div>
<?php
	endif
	?>