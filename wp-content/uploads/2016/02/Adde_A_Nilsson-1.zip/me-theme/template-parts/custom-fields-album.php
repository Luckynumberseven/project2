<?php     
global $post; 
?>

Name of band: 
	<input type="text" name="band_name" value="<?php echo get_post_meta($post->ID, 'band_name', true) ?>" />
Title of album: 
	<input type="text" name="album_title" value="<?php echo  get_post_meta($post->ID, 'album_title', true)?>" />
Release year: 
	<input type="number" name="rel_year" value="<?php echo get_post_meta($post->ID, 'rel_year', true) ?>" />
Record label: 
	<input type="text" name="rec_label" value="<?php echo  get_post_meta($post->ID, 'rec_label', true)?>" /><br>
Record link (use youtube url for auto embed):
	<input type="text" name="url_album" value="<?php echo  get_post_meta($post->ID, 'url_album', true)?>" />

