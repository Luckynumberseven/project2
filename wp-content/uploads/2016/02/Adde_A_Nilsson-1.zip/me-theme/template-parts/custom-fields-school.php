<?php     
global $post; 
?>

Name of education: 
	<input type="text" name="name_of_education" value="<?php echo get_post_meta($post->ID, 'name_of_education', true) ?>" />
Name of school: 
	<input type="text" name="school_name" value="<?php echo  get_post_meta($post->ID, 'school_name', true)?>" />
Type of education 	
<select name="education_type">
<?php
	if( get_post_meta($post->ID, 'education_type', true) == 'course'){
?>		<option selected value="course">course</option>
		<option value="program">program</option>
<?php
	}
 	elseif(get_post_meta($post->ID, 'education_type', true) == 'program'){
 ?>		<option value="course">course</option>
		<option selected value="program">program</option>
<?php 
	}
	else{
?>
		<option>Please choose</option>
		<option value="course">course</option>
		<option value="program">program</option>
<?php 
	} 
?>
</select><br>

education start: 
	<input type="date" name="start" value="<?php echo get_post_meta($post->ID, 'start', true) ?>"/>
education end: 
	<input type="date" name="end" value="<?php echo get_post_meta($post->ID, 'end', true) ?>"/>
Graduated?:
<select name="grad">
<?php
	if( get_post_meta($post->ID, 'grad', true) == 'Yes'){
?>			
		<option selected>Yes</option>
		<option>No</option>
		<option>Not yet</option>
<?php
	}
 	elseif(get_post_meta($post->ID, 'grad', true) == 'No'){
 ?>			
		<option>Yes</option>
		<option selected>No</option>
		<option>Not yet</option>
<?php 
	}
	elseif(get_post_meta($post->ID, 'grad', true) == 'Not yet'){
?>		<option>Yes</option>
		<option selected>No</option>
		<option selected>Not yet</option>
<?php
	}
	else{
?>
		<option>Please choose</option>
		<option>Yes</option>
		<option>No</option>
		<option>Not yet</option>

<?php
	} 
?>
</select>