<?php     
global $post; 
?>

Band name: 
	<input type="text" name="name" required value="<?php echo get_post_meta($post->ID, 'name', true) ?>" />
Band link: 
	<input type="url" name="band_url" value="<?php echo  get_post_meta($post->ID, 'band_url', true)?>" />

Band email:
	<input type="email" name="band_email" value="<?php echo  get_post_meta($post->ID, 'band_email', true)?>" />
	
Is the band active?:	
<select required name="is_active">
<?php
	if( get_post_meta($post->ID, 'is_active', true) == 'Yes'){
?>		<option selected>Yes</option>
		<option>No</option>
<?php
	}
 	elseif(get_post_meta($post->ID, 'is_active', true) == 'No'){
 ?>		<option>Yes</option>
		<option selected>No</option>
<?php 
	}
	else{
?>
		<option></option>
		<option>Yes</option>
		<option>No</option>
<?php 
	} 
?>
</select><br>

Year disbanded:
	<input type="number" name="disband_year" value="<?php echo get_post_meta($post->ID, 'disband_year', true) ?>"/>

Record link (use youtube or soundcloud hosted share-url for auto embed):
	<input type="text" name="song_url" value="<?php echo  get_post_meta($post->ID, 'song_url', true)?>" />