

<?php 
if (is_singular()) :
?>
	<div class="row">
		<div class="col-xs-12 page-content single-band">
			<div class="row">
				<div class="col-xs-6 col-xs-offset-3">
					<img class="img-responsive center-block" src="<?php the_field('logo') ?>" />
				</div>
			</div>
			<div class="row">
				<div class="col-xs-10 col-xs-offset-1">
					<h1><?php echo get_post_meta($post->ID, 'name', true) ?></h1>
					<div class="p-content">
						<p><?php the_content() ?></p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-xs-offset-1">
					<?php 
					if( !empty( get_field('releases') )) : ?>
						<h3>Releases</h3>
						<p><a href="<?php the_field('releases') ?>">Album</a></p>
					<?php 
					endif;?>
					<?php
					if( !empty( get_post_meta($post->ID, 'band_email', true) )) : ?>
						<h3><a href="<?php the_field('url') ?>">Band homepage</a></h3>
						<h3><a href="mailto:<?php echo get_post_meta($post->ID, 'band_email', true) ?>">Mail</a></h3>
					<?php
					endif ?>
					
					<h3>Band status</h3>
					<?php
					if ( get_post_meta($post->ID, 'is_active', true) == 'Yes' ) : ?>
						<p>This band is alive and kicking and you should follow up on them!</p>
					<?php
					else :?>
						<p>This band is not active anymore. 
						<?php
						if( !empty( get_post_meta($post->ID, 'disband_year', true) )) : ?>
							<p>They disbanded in <?php echo get_post_meta($post->ID, 'disband_year', true) ?></p>
						<?php
						endif 
						?>
					<?php
					endif;?>
				</div>

				<div class="col-xs-7 song-box">
					<div class="song-item">
						<?php
						if(!empty(get_post_meta($post->ID, 'song_url', true) )) :
						?>
							<h3>Album stream:</h3>
							<?php
							echo wp_oembed_get(  get_post_meta($post->ID, 'song_url', true) );
							?>
						<?php
						endif
						?>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php
elseif (is_archive()) :
?>
	<div class="row">
		<div class="col-xs-6">
			<h1><a href=" <?php the_permalink() ?>"><?php the_title() ?></a></h1>
			<?php the_excerpt();?>
		</div>
		<div class="col-xs-6">
			<img class="img-responsive center-block" src="<?php the_field('logo')?>" />
		</div>
	</div>
<?php	
endif
?>