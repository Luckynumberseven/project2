<?php
if(  is_single()) :
?>

	<div class="row">
		<div class="col-xs-12 page-content">
			<div class="row">
				<div class="col-xs-4 col-xs-offset-4">
					<img class="img-responsive" src="<?php the_field('_cover') ?>" />
				</div>
				<div class="row">
				<div class="col-xs-8 col-xs-offset-2">
					<h1 class="text-center"><?php the_title() ?></h1>
					<div class="p-content">
						<p><?php the_content() ?></p>
					</div>
				</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-xs-offset-2">

					<?php
					if(!empty(get_post_meta($post->ID, 'album_title', true)) ) :?>
						<h3>Album title: </h3>
						<p><?php echo ucfirst(get_post_meta($post->ID, 'album_title', true)) ?></p>
					<?php
					endif
					?>
					<?php
					if(!empty(get_post_meta($post->ID, 'band_name', true)) ) :?>
						<h3>Band name: </h3>
						<p><?php echo ucfirst(get_post_meta($post->ID, 'band_name', true)) ?></p>
					<?php
					endif
					?>
					<?php
					if(!empty( get_post_meta($post->ID, 'rel_year', true)) ) :?>
						<h3>Release year:</h3>
						<p><?php echo get_post_meta($post->ID, 'rel_year', true) ?></p>
					<?php
					endif
					?>
					<?php
					if(!empty(get_post_meta($post->ID, 'rec_label', true) )) :?>
						<h3>Record label:</h3>
						<p><?php echo ucfirst(get_post_meta($post->ID, 'rec_label', true)) ?></p>
					<?php
					endif
					?>

					<?php
					if(!empty(get_the_terms($post->id, 'genre', '', '', ''))) :
						the_terms($post->id, 'genre', '<h3>Genres:</h3>', ', ', '.');
					endif
					?>
				</div>
				<div class="col-xs-4">
					<div class="album-link">
						<?php
						if(!empty(get_post_meta($post->ID, 'url_album', true) )) :
						?>
							<h3>Album stream:</h3>
							<?php
							echo wp_oembed_get(  get_post_meta($post->ID, 'url_album', true) );
							?>
						<?php
						endif
						?>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php
elseif(is_archive()) :
?>
	<div class="row">
		<div class="col-xs-5">
		<?php if( !empty( get_field('_cover') ) ) : ?>
			<a href="<?php the_permalink() ?>">
				<img class="img-responsive center-block" src="<?php the_field('_cover') ?>" />
			</a>
		<?php endif ?>
		</div>
		<div class="col-xs-7">
			<a href="<?php the_permalink() ?>"><h3><?php the_title() ?> - <?php the_field('title') ?></h3>
			<p><?php the_content() ?></p></a>
		</div>
	</div>
<?php 
endif
?>


