<?php     
global $post; 
?>

Project name: 
	<input type="text" name="name" value="<?php echo get_post_meta($post->ID, 'name', true) ?>" />
Project link: 
	<input type="text" name="project_url" value="<?php echo  get_post_meta($post->ID, 'project_url', true)?>" />
Project year: 
	<input type="number" name="project_year" value="<?php echo get_post_meta($post->ID, 'project_year', true) ?>" />
Collaborators: 
	<input type="text" name="people" value="<?php echo  get_post_meta($post->ID, 'people', true)?>" />