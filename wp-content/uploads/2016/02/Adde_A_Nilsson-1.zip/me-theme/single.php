<?php get_header() ?>

<?php
if( have_posts()) : 
	while( have_posts() ) : the_post();
?>
		<div class="row ">
			<div class="col-xs-12 page-head">
					<h1 class=""><?php the_title(); ?></h1>
				<p class="">Publicerad av <?php the_author() ?> <?php the_time("Y:m:d H:m") ?></p>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 page-content">
				<div class="row">
					<div class="col-xs-9">
						<?php the_content() ?>
					</div>
					<div class="col-xs-3">
						<?php get_sidebar(); ?>
					</div>
				</div>		
			</div>
		</div>	
	<?php
	endwhile;		
else : 
?>
	<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php 
endif; ?>

<?php get_footer() ?>