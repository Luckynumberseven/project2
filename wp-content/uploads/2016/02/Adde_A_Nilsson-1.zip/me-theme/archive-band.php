<?php
get_header();
?>
<div class="row">

	<div class="col-xs-12 page-head text-center">
		<h1 class=""><?php the_archive_title();?></h1>
		<p>This is the archive page for bands. Here you'll find links to all bands posted on the site.</p>
		<h3>Browse bands and albums by genre:</h3>
		<?php
			/* Gets all the terms within the taxonomy for this custom post type */
				$separator = ', ';
				$terms = wp_list_categories( 'title_li=&style=none&echo=0&taxonomy=genre&include=' );
				$terms = rtrim( trim( str_replace( '<br />',  $separator, $terms ) ), $separator );
				
				// display post taxonomy terms
				echo  $terms;
			?>
	</div>
</div>

<div class="row"><!--main-row-->

	<div class="col-xs-12  page-content"><!--main-col-->

		<div class="row">
			<div class="col-xs-9 archive-band">
				<?php
				//Sorterar om så äldsta inlägg hamnar först
				query_posts($query_string."&orderby=date&order=ASC"); 
				if( have_posts() ) :
					while ( have_posts() ) : the_post(); 

						get_template_part('template-parts/partial-band');

					endwhile;
					
				else : ?>
						<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
					<?php 
					endif;
					?>
			</div>
			<div class="col-xs-3">
				<?php
					get_sidebar();
				?>
			</div>
		</div>
	</div><!--/main-col-->
</div><!--/main-row-->

<div class="row">
	<div class="col-xs-12">
		<?php
		get_footer();
		?>
	</div>
</div>